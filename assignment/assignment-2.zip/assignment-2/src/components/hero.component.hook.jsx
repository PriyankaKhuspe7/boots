import { useDispatch, useSelector } from "react-redux";
import {addHero} from "../redux";

let HeroHookComponent=() =>{
    let numOfHeroes = useSelector(function(state){return state.heroReducer.numOfHeroes});
    let dispatch =useDispatch();
    return <div>
        <h2>Usinr React Redux With Hooks</h2>
        <h3>Number Of Heroes : {numOfHeroes}</h3>
        <button onClick={()=> dispatch(addHero())}>Add Hero</button>
    </div>
}
export default HeroHookComponent;