import addHero from "./hero/actions/hero.actions";
import addMovie from "./movie/action/movie.action";

export  {addHero, addMovie};
