import ADD_MOVIE from "../types/movie.types"
const addMovie = () => {
    return{
        type : ADD_MOVIE
    }
};
export default addMovie;